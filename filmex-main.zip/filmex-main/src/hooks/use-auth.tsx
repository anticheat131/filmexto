// This file is deprecated. Import from '@/hooks' instead.
