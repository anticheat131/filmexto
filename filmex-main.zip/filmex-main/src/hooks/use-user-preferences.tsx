// This file is deprecated. Import from '@/hooks/user-preferences' instead.
