// This file is deprecated. Import from '@/hooks/watch-history' instead.
