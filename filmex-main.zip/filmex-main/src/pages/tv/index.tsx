
import TVShowsPage from './TVShowsPage';

export default TVShowsPage;
